Middleware - Active Report
==========================
.. automodule:: middleware.report_generator.src.active_report
    :members:
    :inherited-members:


Middleware - Report Runner
==========================
.. automodule:: middleware.query_engine.report_runner
    :members:
    :inherited-members:
