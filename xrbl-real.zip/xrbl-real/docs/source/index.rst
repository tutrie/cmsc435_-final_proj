.. XRBL Scraper documentation master file, created by
   sphinx-quickstart on Mon Apr 19 13:11:21 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to XRBL Scraper's documentation!
========================================

.. toctree::
   flask_ui
   django_api
   middleware
   :maxdepth: 2
   :caption: Contents


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
